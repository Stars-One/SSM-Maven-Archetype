create function avg_sal(p_deptno employee.sal%type)
	return employee.sal%type
	is
		v_avg_sal employee.sal%type;
	begin
		select avg(nvl(sal,0)) into v_avg_sal from employee where deptno=p_deptno;
		return v_avg_sal;
	end avg_sal;
/

