create function fun_generate_ano
	return varchar
	is
		v_temp varchar(14);
		v_result varchar(16);
	begin
		select substr(to_char(dbms_random.value,'0.999999999999999'),7) into v_temp from dual;
		v_result := '6722'||v_temp;
		return v_result;
	end fun_generate_ano;
/

