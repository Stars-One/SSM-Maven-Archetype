create procedure query_trade(p_ano account.ano%type,p_startdate date,p_enddate date)
is
	v_pay_money trade_log.tmoney%type;
	v_get_money trade_log.tmoney%type;
begin
	select sum(tmoney) into v_pay_money from trade_log where tdate >=p_startdate and tdate <=p_enddate and  p_ano = foac;
	select sum(tmoney) into v_get_money from trade_log where tdate >=p_startdate and tdate <=p_enddate and  p_ano = toac;
	dbms_output.put_line('支出'||v_pay_money||',转入'||v_get_money);
end;
/

