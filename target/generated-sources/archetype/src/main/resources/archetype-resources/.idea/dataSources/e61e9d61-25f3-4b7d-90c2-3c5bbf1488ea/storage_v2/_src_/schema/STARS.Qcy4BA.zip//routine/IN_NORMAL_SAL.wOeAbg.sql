create function in_normal_sal(num employee.sal%type)
	return varchar2
	is
		min_num employee.sal%type;
		max_num employee.sal%type;

	begin
		--select min(sal) into min_num from employee;
		--select max(sal) into max_num from employee;
    select min(sal),max(sal) into min_num,max_num from employee;
    --select ename into myname,empno into myempno from employee where ename='JAMES';
		if num >= min_num and num <=max_num then
			return '在';
		else
			return '不在';
		end if;
	end in_normal_sal;
/

