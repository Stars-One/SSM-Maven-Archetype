create procedure open_account(p_aname account.aname%type,p_aid account.aid%type,p_remainder in out account.remainder%type )
is
	v_ano account.ano%type;
	v_temp varchar(12) ;
begin
	v_ano := fun_generate_ano();
	insert into account values(v_ano,p_aname,p_aid,p_remainder,localtimestamp);
  commit;
end open_account;
/

