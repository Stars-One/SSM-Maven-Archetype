create procedure show_avg_sal
	is
		cursor cur_dep is select * from department;
		rec_dept department%rowtype;
		v_sal employee.sal%type;
    v_dname department.dname%type;
	begin
		for rec_dept in cur_dep loop
			select dname,avg_sal(deptno) into v_dname, v_sal from department where rec_dept.deptno=deptno;
			dbms_output.put_line(v_dname||',部门平均工资为'||nvl(v_sal,0));
		end loop;
	end show_avg_sal;
/

