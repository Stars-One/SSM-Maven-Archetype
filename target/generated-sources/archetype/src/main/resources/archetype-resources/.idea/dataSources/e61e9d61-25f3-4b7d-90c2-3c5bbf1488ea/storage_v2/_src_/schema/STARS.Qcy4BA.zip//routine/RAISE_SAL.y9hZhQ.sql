create procedure Raise_Sal(p_ename employee.ename%type)
is
	cursor cur_emp is select * from employee where ename = p_ename for update;
	v_emp employee%rowtype;
begin
	for v_emp in cur_emp loop
		update employee set sal=sal+sal*0.1 where current of cur_emp;
		if months_between(sysdate,v_emp.hiredate)>=60 then
			update employee set sal=sal+3000 where current of cur_emp;
		end if;
	end loop;
	commit;
end Raise_Sal;
/

