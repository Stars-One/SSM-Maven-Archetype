create procedure transaction_account(p_fono account.ano%type,
	p_tono account.ano%type,
	p_money account.remainder%type)
is
	v_temp number;
	ex_fono_nofound exception;--转出方不存在
	ex_tono_nofound exception;--转入方不存在
	ex_nomoney exception;--余额不足
	v_money account.remainder%type;
  v_tno trade_log.tno%type;
begin
	--检查账户是否存在
	select count(*) into v_temp from account where ano=p_fono;
	if v_temp<>1 then
		raise ex_fono_nofound;
	end if;
	select count(*) into v_temp from account where ano=p_tono;
	if v_temp<>1 then
		raise ex_tono_nofound;
	end if;
	--检查余额
  savepoint m1;
	select remainder into v_money from account where ano =p_fono;
	if v_money<p_money then
		raise ex_nomoney;
	end if;
	--转账操作，更新两个账户的余额

	update account set remainder=remainder-p_money where ano = p_fono;
	update account set remainder = remainder+p_money where ano =p_tono;
	--trade_log：tno交易号，foac转出账户，toac转入账户，tmoney交易金额，tdate交易时间(systimestamp时间截)。
  v_tno := sys_guid();
	insert into trade_log values(v_tno,p_fono,p_tono,p_money,localtimestamp);
	commit;

	exception
		when ex_fono_nofound then
			raise_application_error(-20000,'转出方不存在');
		when ex_tono_nofound then
			raise_application_error(-20001,'转入方不存在');
		when ex_nomoney then
			rollback to savepoint m1;
			raise_application_error(-20002,'余额不足');
end transaction_account;
/

